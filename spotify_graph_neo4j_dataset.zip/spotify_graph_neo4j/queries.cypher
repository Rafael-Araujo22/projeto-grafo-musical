// Consultas de negócio — Spotify Graph
// Execute uma consulta por vez.

// Q1. Visualizar o grafo inteiro (bom para dataset pequeno).
MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 100;

// Q2. Músicas de um artista específico.
MATCH (a:Artist {name:'Luna Costa'})<-[:PERFORMED_BY]-(s:Song)
RETURN s.title AS musica, s.duration_sec AS duracao_segundos
ORDER BY musica;

// Q3. Artistas com mais reproduções registradas.
// play_count é a contagem de reproduções agregada em cada relação usuário-música.
MATCH (u:User)-[r:LISTENED_TO]->(s:Song)-[:PERFORMED_BY]->(a:Artist)
RETURN a.name AS artista, sum(r.play_count) AS reproducoes
ORDER BY reproducoes DESC;

// Q4. Gêneros mais ouvidos.
MATCH (:User)-[r:LISTENED_TO]->(s:Song)-[:HAS_GENRE]->(g:Genre)
RETURN g.name AS genero, sum(r.play_count) AS reproducoes
ORDER BY reproducoes DESC;

// Q5. Recomendar músicas que usuários parecidos ouviram e o usuário-alvo ainda não ouviu.
// "Parecido" aqui significa compartilhar ao menos uma música ouvida; é uma regra demonstrativa simples.
MATCH (alvo:User {name:'Rafa'})-[:LISTENED_TO]->(comum:Song)<-[:LISTENED_TO]-(outro:User)
MATCH (outro)-[hist:LISTENED_TO]->(recomendada:Song)
WHERE NOT (alvo)-[:LISTENED_TO]->(recomendada)
RETURN recomendada.title AS recomendacao,
       count(DISTINCT outro) AS usuarios_que_sugerem,
       sum(hist.play_count) AS reproducoes_nesses_historicos
ORDER BY usuarios_que_sugerem DESC, reproducoes_nesses_historicos DESC;

// Q6. Descobrir colaborações entre artistas.
MATCH (a:Artist)-[r:COLLABORATED_WITH]-(b:Artist)
RETURN DISTINCT a.name AS artista_1, b.name AS artista_2, r.year AS ano
ORDER BY ano;

// Q7. Músicas que aparecem em mais de um artista (participações).
MATCH (s:Song)-[r:PERFORMED_BY]->(a:Artist)
WITH s, collect(a.name + ' (' + r.role + ')') AS artistas
WHERE size(artistas) > 1
RETURN s.title AS musica, artistas;

// Q8. Histórico de audição do usuário.
MATCH (u:User {name:'Rafa'})-[r:LISTENED_TO]->(s:Song)
RETURN s.title AS musica, r.play_count AS reproducoes,
       r.completed AS terminou, r.last_played AS ultima_audicao
ORDER BY ultima_audicao DESC;

// Q9. Duração média das músicas por gênero.
MATCH (s:Song)-[:HAS_GENRE]->(g:Genre)
RETURN g.name AS genero,
       round(avg(s.duration_sec)) AS duracao_media_segundos,
       count(s) AS quantidade_musicas
ORDER BY quantidade_musicas DESC;

// Q10. Artistas relacionados a músicas que Rafa ouviu.
MATCH (:User {name:'Rafa'})-[:LISTENED_TO]->(s:Song)-[:PERFORMED_BY]->(a:Artist)
RETURN DISTINCT a.name AS artista, s.title AS musica
ORDER BY artista;
