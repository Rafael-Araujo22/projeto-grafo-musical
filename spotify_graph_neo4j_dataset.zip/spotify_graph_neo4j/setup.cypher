// Spotify Graph — dataset demonstrativo fictício
// Execute as seções na ordem indicada em um banco Neo4j Aura vazio.

// 1) IDs únicos: impedem duplicações acidentais.
CREATE CONSTRAINT artist_id_unique IF NOT EXISTS
FOR (n:Artist) REQUIRE n.artist_id IS UNIQUE;
CREATE CONSTRAINT album_id_unique IF NOT EXISTS
FOR (n:Album) REQUIRE n.album_id IS UNIQUE;
CREATE CONSTRAINT song_id_unique IF NOT EXISTS
FOR (n:Song) REQUIRE n.song_id IS UNIQUE;
CREATE CONSTRAINT user_id_unique IF NOT EXISTS
FOR (n:User) REQUIRE n.user_id IS UNIQUE;
CREATE CONSTRAINT genre_name_unique IF NOT EXISTS
FOR (n:Genre) REQUIRE n.name IS UNIQUE;

// 2) Criar artistas.
UNWIND [
 {id:'A1',name:'Luna Costa',country:'Brasil'},
 {id:'A2',name:'Caio Mendes',country:'Brasil'},
 {id:'A3',name:'Neon Avenue',country:'Estados Unidos'},
 {id:'A4',name:'Maya Sol',country:'Portugal'},
 {id:'A5',name:'DJ Horizonte',country:'Brasil'},
 {id:'A6',name:'The Paper Moons',country:'Reino Unido'}
] AS row
MERGE (a:Artist {artist_id:row.id})
SET a.name=row.name, a.country=row.country;

// 3) Criar álbuns.
UNWIND [
 {id:'AL1',title:'Cidade em Neon',year:2023},
 {id:'AL2',title:'Maré Alta',year:2024},
 {id:'AL3',title:'After Midnight',year:2022},
 {id:'AL4',title:'Céu Aberto',year:2025}
] AS row
MERGE (a:Album {album_id:row.id})
SET a.title=row.title, a.release_year=row.year;

// 4) Criar músicas, gêneros e relações com álbum.
UNWIND [
 {id:'S1',title:'Luzes da Cidade',duration:212,album:'AL1',genre:'Pop'},
 {id:'S2',title:'Chuva de Verão',duration:187,album:'AL1',genre:'MPB'},
 {id:'S3',title:'Maré Alta',duration:231,album:'AL2',genre:'Indie Pop'},
 {id:'S4',title:'Sem Sinal',duration:205,album:'AL2',genre:'Pop'},
 {id:'S5',title:'Midnight Drive',duration:244,album:'AL3',genre:'Electronic'},
 {id:'S6',title:'Paper Hearts',duration:198,album:'AL3',genre:'Indie Pop'},
 {id:'S7',title:'Céu Aberto',duration:219,album:'AL4',genre:'MPB'},
 {id:'S8',title:'Dança Lunar',duration:176,album:'AL4',genre:'Electronic'},
 {id:'S9',title:'Entre Nós',duration:225,album:'AL1',genre:'MPB'}
] AS row
MERGE (s:Song {song_id:row.id})
SET s.title=row.title, s.duration_sec=row.duration
MERGE (al:Album {album_id:row.album})
MERGE (s)-[:IN_ALBUM]->(al)
MERGE (g:Genre {name:row.genre})
MERGE (s)-[:HAS_GENRE]->(g);

// 5) Relacionar músicas e artistas (inclui participações).
UNWIND [
 {song:'S1',artist:'A1',role:'principal'},
 {song:'S2',artist:'A1',role:'principal'},
 {song:'S3',artist:'A2',role:'principal'},
 {song:'S4',artist:'A2',role:'principal'},
 {song:'S4',artist:'A1',role:'participacao'},
 {song:'S5',artist:'A3',role:'principal'},
 {song:'S6',artist:'A6',role:'principal'},
 {song:'S7',artist:'A4',role:'principal'},
 {song:'S8',artist:'A5',role:'principal'},
 {song:'S8',artist:'A3',role:'participacao'},
 {song:'S9',artist:'A1',role:'principal'},
 {song:'S9',artist:'A4',role:'participacao'}
] AS row
MATCH (s:Song {song_id:row.song})
MATCH (a:Artist {artist_id:row.artist})
MERGE (s)-[r:PERFORMED_BY {role:row.role}]->(a);

// 6) Criar usuários.
UNWIND [
 {id:'U1',name:'Rafa',country:'Brasil'},
 {id:'U2',name:'Bia',country:'Brasil'},
 {id:'U3',name:'Leo',country:'Portugal'},
 {id:'U4',name:'Nina',country:'Brasil'}
] AS row
MERGE (u:User {user_id:row.id})
SET u.name=row.name, u.country=row.country;

// 7) Histórico de audições. played_at é guardado como texto ISO para simplificar.
UNWIND [
 {user:'U1',song:'S1',at:'2026-10-20T19:30:00',count:5,completed:true},
 {user:'U1',song:'S4',at:'2026-10-21T20:00:00',count:3,completed:true},
 {user:'U1',song:'S9',at:'2026-10-22T21:15:00',count:4,completed:true},
 {user:'U1',song:'S8',at:'2026-10-23T18:10:00',count:2,completed:false},
 {user:'U2',song:'S1',at:'2026-10-20T08:00:00',count:2,completed:true},
 {user:'U2',song:'S2',at:'2026-10-21T08:20:00',count:6,completed:true},
 {user:'U2',song:'S7',at:'2026-10-22T08:30:00',count:3,completed:true},
 {user:'U2',song:'S9',at:'2026-10-23T09:00:00',count:1,completed:true},
 {user:'U3',song:'S3',at:'2026-10-20T14:00:00',count:4,completed:true},
 {user:'U3',song:'S5',at:'2026-10-21T23:10:00',count:7,completed:true},
 {user:'U3',song:'S8',at:'2026-10-22T23:30:00',count:3,completed:true},
 {user:'U4',song:'S4',at:'2026-10-20T17:40:00',count:5,completed:true},
 {user:'U4',song:'S6',at:'2026-10-21T18:00:00',count:2,completed:true},
 {user:'U4',song:'S3',at:'2026-10-22T17:00:00',count:3,completed:false},
 {user:'U4',song:'S5',at:'2026-10-23T22:00:00',count:2,completed:true}
] AS row
MATCH (u:User {user_id:row.user})
MATCH (s:Song {song_id:row.song})
MERGE (u)-[r:LISTENED_TO]->(s)
SET r.last_played = datetime(row.at),
    r.play_count = row.count,
    r.completed = row.completed;

// 8) Colaborações entre artistas. MERGE evita repetir a relação em reexecuções.
UNWIND [
 {a1:'A1',a2:'A2',year:2024},
 {a1:'A1',a2:'A4',year:2025},
 {a1:'A3',a2:'A5',year:2025}
] AS row
MATCH (a:Artist {artist_id:row.a1})
MATCH (b:Artist {artist_id:row.a2})
MERGE (a)-[r:COLLABORATED_WITH]-(b)
SET r.year=row.year;

// 9) Conferir contagens.
MATCH (n) RETURN labels(n) AS labels, count(*) AS quantidade ORDER BY labels;
