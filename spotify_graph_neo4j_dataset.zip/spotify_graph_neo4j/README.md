# Spotify Graph — Neo4j Aura

Projeto demonstrativo de streaming musical com dados **100% fictícios**.

## Objetivo
Modelar artistas, músicas, álbuns, gêneros e usuários como um grafo e responder perguntas sobre popularidade, colaborações, histórico e recomendações simples.

## Modelo
- `(:User)-[:LISTENED_TO {play_count, last_played, completed}]->(:Song)`
- `(:Song)-[:PERFORMED_BY {role}]->(:Artist)`
- `(:Song)-[:IN_ALBUM]->(:Album)`
- `(:Song)-[:HAS_GENRE]->(:Genre)`
- `(:Artist)-[:COLLABORATED_WITH {year}]-(:Artist)`

## Arquivos
- `setup.cypher`: cria constraints, nós e relacionamentos usando `UNWIND` e `MERGE`; adequado para colar no Query editor do Aura.
- `queries.cypher`: consultas de negócio.
- `artists.csv`, `albums.csv`, `songs.csv`, `song_artists.csv`, `users.csv`, `listens.csv`, `collaborations.csv`: dataset tabular equivalente para demonstrar importação CSV.

## Como executar no Aura
1. Crie uma instância Neo4j AuraDB e abra o Query/Query editor.
2. Em uma instância vazia, copie e execute as seções de `setup.cypher` na ordem. Execute cada bloco separado se o editor não aceitar várias consultas de uma vez.
3. Execute uma consulta por vez de `queries.cypher`.
4. Salve capturas de tela do modelo e dos resultados para o README.

## Importação CSV com LOAD CSV
O Aura não lê automaticamente arquivos do seu computador via `file:///`. Para usar `LOAD CSV`, publique os CSVs em um endereço HTTPS acessível pelo banco (por exemplo, arquivos raw de um repositório público no GitHub) e substitua a URL de exemplo pelo endereço real. Confira permissões e evite colocar dados pessoais reais.
Exemplo:
```cypher
LOAD CSV WITH HEADERS
FROM 'https://raw.githubusercontent.com/SEU_USUARIO/SEU_REPOSITORIO/main/artists.csv'
AS row
MERGE (a:Artist {artist_id: row.artist_id})
SET a.name = row.name, a.country = row.country;
```
Depois faça o mesmo para os demais arquivos, convertendo tipos com `toInteger()` e `datetime()` quando necessário. A ordem típica é: artistas/álbuns/usuários, músicas/gêneros, relações música-artista e, por fim, audições.

## Conceitos Cypher
- `CREATE`: cria sempre; pode duplicar dados se executar novamente.
- `MERGE`: encontra ou cria o padrão, útil para cargas repetíveis.
- `MATCH`: localiza nós/relacionamentos existentes.
- `SET`: define ou atualiza propriedades.
- `RETURN`: mostra os resultados.
- `UNWIND`: transforma uma lista de mapas em linhas para processar em lote.
- `CREATE CONSTRAINT`: aplica regras de unicidade aos IDs.

## Perguntas de negócio demonstradas
1. Quais artistas somam mais reproduções?
2. Quais gêneros são mais ouvidos?
3. Que músicas podem ser recomendadas a Rafa pelo histórico de usuários com gostos em comum?
4. Quais artistas colaboraram?
5. Quais músicas têm participações?
6. Qual a duração média por gênero?

## Troubleshooting
- `Variable ... already declared` ou erro de sintaxe: execute uma seção de cada vez.
- Dados duplicados: prefira `MERGE` e IDs estáveis; `CREATE` cria duplicatas se repetido.
- `LOAD CSV` falha: confirme que a URL é HTTPS, pública, direta para o CSV e acessível sem login.
- `MATCH` retorna zero linhas: confira IDs, grafia e se a seção que cria os nós já foi executada.
- Datas: use `datetime()` para transformar texto ISO em valor temporal.
- Reexecutar `setup.cypher`: os nós são protegidos por `MERGE`; se já existirem dados antigos com relações duplicadas de outro modelo, inspecione antes de limpar.

## Melhorias futuras
- Adicionar playlists, avaliações, artistas favoritos e histórico por evento de reprodução.
- Comparar a recomendação baseada em vizinhos com uma abordagem por gênero ou similaridade.
- Adicionar testes de consistência e explicar limites do dataset sintético.

## Aviso
Os nomes, usuários, dados de reprodução e relações foram inventados para fins educacionais; não representam dados reais do Spotify.
